package com.dada.kenacPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KenacPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
